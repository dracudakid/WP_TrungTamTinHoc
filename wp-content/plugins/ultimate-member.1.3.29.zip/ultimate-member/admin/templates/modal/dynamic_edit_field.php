<div id="UM_edit_field" style="display:none">

	<form action="" method="post" class="um_add_field">
	
	<div class="um-admin-modal-head">
		<h3><?php _e('Edit Field','ultimatemember'); ?></h3>
	</div>
	
	<div class="um-admin-modal-body um-admin-metabox">

	</div>

	<div class="um-admin-modal-foot">
		<input type="submit" value="<?php _e('Update','ultimatemember'); ?>" class="button-primary" />
		<a href="#" data-action="UM_remove_modal" class="button"><?php _e('Cancel','ultimatemember'); ?></a>
	</div>
	
	</form>
	
</div>